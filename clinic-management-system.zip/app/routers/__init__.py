from app.routers import auth, patient

__all__= [
    "auth",
    "patient",
]